/*

Create Accounts Table

*/

Create Table Accounts
(
  AccountId Int Not Null
, CustomerId Int Not Null
, TypeCde Char(6) Not Null
, OpenDate Date Not Null 
, BalanceAmt Decimal(18,2) Not Null 
, Constraint pkAccounts Primary Key (AccountID)
, Constraint fkAccountsCustomers Foreign Key (CustomerId) References Customers(CustomerId)
, Constraint fkAccountType Foreign Key (TypeCde) References ReferenceData(TypeCde)
)
;

/*

Insert test data

*/

Insert Into Accounts (AccountId, CustomerId, TypeCde, OpenDate, BalanceAmt)
Values
  (1, 1, 'Acc001', '2018-01-01', 10000)
, (2, 1, 'Acc002', '2018-01-01', 50000)
, (3, 1, 'Acc003', '2018-01-01', 100000)
, (4, 2, 'Acc001', '2018-01-01', 35000)
, (5, 2, 'Acc003', '2018-01-01', 500000)
, (6, 3, 'Acc001', '2018-01-01', 500000)
, (7, 3,'Acc001', '2018-01-01', 250000)
, (8, 4, 'Acc001', '2018-01-01', 15000000)
, (9, 5, 'Acc001', '2018-01-01', 25000000)
, (10, 6, 'Acc001', '2018-01-01', 1000000)
, (11, 7, 'Acc001', '2018-01-01', 50000000)
, (12, 7, 'Acc003', '2018-01-01', 10000000)
, (13, 7, 'Acc002', '2018-01-01', 5000000)
;

Select * from Accounts
;

/*

Test primary key constraint

Expected result is an error "Violation of Primary Key constraint"

*/


Insert Into Accounts (AccountId, CustomerId, TypeCde, OpenDate, BalanceAmt)
Values
  (5, 1, 'Acc001', '2018-01-01', 10000)
  ;
