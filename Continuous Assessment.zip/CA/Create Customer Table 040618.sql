/*

Create customer table. 

Identity is not set as data will be imported from existing systems

*/

Create Table Customers
(
CustomerID Int Not Null
, CustomerType Char(1) Not Null
, Name VarChar(50) Not Null
, DateOfBirth Date
, Address1 VarChar(30)
, Address2 VarChar(30)
, City VarChar(30)
, County VarChar(30)
, Country VarChar(30)
, PhoneNo VarChar(20)
, Constraint pkCustomer Primary Key (CustomerID)
)
;

/*

Insert test data

*/

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values
(1, 'P', 'Mr Noel Linnane', '1983-12-24', '40 Stratton Grove', 'Adamstown Square', 'Adamstown', 'Co. Dublin', 'Ireland', '0852853273')
, (2, 'P', 'Mr Peter Linnane', '1959-03-26', '36 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0876884994')
, (3, 'P', 'Mrs Catherine Linnane', '1958-04-12', '36 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0851122698')
, (4, 'C', 'Insurance Co. Ltd', Null, '3 Sandyford Business Centre', 'Blackthorn Road', 'Sandyford', 'Co. Dublin', 'Ireland', '0162421717')
, (5, 'C', 'Surveyor Co. Ltd', Null, '4 Dunboyne Business Park', 'Dunboyne Road', 'Dunboyne', 'Co. Meath', 'Ireland', '0452543276')
, (6, 'C', 'Powderly Accountants', Null, '35 Kilcock Office Cente', 'The Square', 'Kilcock', 'Co. Kildare', 'Ireland', '016287463')
, (7, 'C', 'Castlethorn Property Development', Null, 'Usher House', 'Main Street', 'Dundrum', 'Co. Dublin', 'Ireland', '012164060')
;


Select * From Customers;

/*

Test primary key constraint

Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values
(1, 'P', 'Mr Andrew Linnane', '1980-03-24', '30 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0851234567')
;