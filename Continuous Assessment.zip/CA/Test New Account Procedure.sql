/*

Test

*/

Exec uspNewAccountAndAssociation
@CustomerId = 9
,@CustomerType = 'P'
,@Name = 'Mr Stephen Linnane'
,@DateOfBirth = '1986-03-26'
,@Address1 = '36 Courtown Park'
,@Address2 = 'Courtown Road'
,@City = 'Kilcock'
,@County = 'Co. Kildare'
,@Country = 'Ireland'
,@PhoneNo = '0851235876'
,@AssociationId = 9
,@AssociatedCustomerId = 4
,@AssociationType = 'Ass001'
;

Select * from Customers
;

Select * from Associations
;