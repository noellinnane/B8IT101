/*

New Account and Association 

*/

Create Procedure uspNewAccountAndAssociation
@CustomerID Int
,@CustomerType Char(1)
,@Name VarChar(50)
,@DateOfBirth Date = Null
,@Address1 VarChar(30) = Null
,@Address2 VarChar(30) = Null
,@City VarChar(30) = Null
,@County VarChar(30) = Null
,@Country VarcHar(30) = Null
,@PhoneNo VarChar(20) = Null
,@AssociationId Int = Null
,@AssociatedCustomerId Int = Null
,@AssociationType Char(6) = Null

As

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values (@CustomerID, @CustomerType, @Name, @DateOfBirth, @Address1, @Address2, @City, @County, @Country, @PhoneNo)
;

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values (@AssociationId, @CustomerId, @AssociatedCustomerId, @AssociationType)
;

