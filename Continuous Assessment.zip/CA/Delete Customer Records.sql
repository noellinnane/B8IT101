Create Procedure uspDeleteCustomerRecords
@CustomerId Int

AS

Delete from Securities 

Where CustomerId = @CustomerId
;

Delete From Accounts

Where CustomerId = @CustomerId
;

Delete From Associations

Where CustomerIdA = @CustomerId
;

Delete from Associations

Where CustomerIdB = @CustomerId
;

Delete From Customers

Where CustomerID = @CustomerId
