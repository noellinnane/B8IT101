/*

Test of primary key constraint. 

ReferenceData

Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into ReferenceData (TypeCde, ReferenceType, TypeDescription, LastStatusCde, LastStatusDte)
Values
('Acc001', 'Account', 'Personal Loan', 'I', '2018-01-01')
;



/*

Test primary key constraint

Customers

Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values
(1, 'P', 'Mr Andrew Linnane', '1980-03-24', '30 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0851234567')
;



/*

Test of primary key constraint. 

Associations

Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (1, 1, 4, 'Ass003')
  ;

/*

Test Unique Constraint

Associations

Customer cannot be associated with same customer more than once with the same association type

*/

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (8, 1, 4, 'Ass001')
  ;


/*

Test primary key constraint

Accounts

Expected result is an error "Violation of Primary Key constraint"

*/


Insert Into Accounts (AccountId, CustomerId, TypeCde, OpenDate, BalanceAmt)
Values
  (5, 1, 'Acc001', '2018-01-01', 10000)
  ;


/*

Test of primary key constraint. 

Securities

Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Securities (SecurityId, AccountId, CustomerId, TypeCde, SecurityValue, ValuationDate)
Values
  (1, 5, 5, 'Sec003', 100000, '2018-01-01')
  ;

/*

Test of New Account & Association Procedure

*/

Exec uspNewAccountAndAssociation
@CustomerId = 9
,@CustomerType = 'P'
,@Name = 'Mr Stephen Linnane'
,@DateOfBirth = '1986-03-26'
,@Address1 = '36 Courtown Park'
,@Address2 = 'Courtown Road'
,@City = 'Kilcock'
,@County = 'Co. Kildare'
,@Country = 'Ireland'
,@PhoneNo = '0851235876'
,@AssociationId = 9
,@AssociatedCustomerId = 4
,@AssociationType = 'Ass001'
;

Select * from Customers
;

Select * from Associations
;


/*

Test of Delete Customer Records Procedurs

*/

Exec uspDeleteCustomerRecords 
@CustomerId = 9
;


