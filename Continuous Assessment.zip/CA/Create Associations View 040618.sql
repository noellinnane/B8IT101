Create View usvAssocationsMi
As
	Select a.AssociationId
	, a.CustomerIdA as CustomerId
	, b.Name as CustomerName
	, a.CustomerIdB as AssociatedCustomerId
	, c.Name as AssociatedCustomerName
	, a.TypeCde
	, d.TypeDescription
	, 'Left side' as RelationshipSide

	from Associations a
	join Customers b
	on a.CustomerIdA = b.CustomerId

	join Customers c
	on a.CustomerIdB = c.CustomerId

	join ReferenceData d
	on a.TypeCde = d.TypeCde

	UNION

	Select a.AssociationId
	, a.CustomerIdB as CustomerId
	, b.Name as CustomerName
	, a.CustomerIdA as AssociatedCustomerId
	, c.Name as AssociatedCustomerName
	, a.TypeCde
	, d.TypeDescription
	, 'Right side' as RelationshipSide

	from Associations a
	join Customers b
	on a.CustomerIdB = b.CustomerId

	join Customers c
	on a.CustomerIdA = c.CustomerId

	join ReferenceData d
	on a.TypeCde = d.TypeCde
;