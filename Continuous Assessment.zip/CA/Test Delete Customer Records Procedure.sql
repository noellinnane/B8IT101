Exec uspDeleteCustomerRecords 
@CustomerId = 1