/*

Create Generic Reference Data Table allowing Soft Deletes

*/

CREATE TABLE ReferenceData
(
TypeCde	Char(6) Not Null
, ReferenceType VarChar(30) Not Null
, TypeDescription VarChar(30) Not Null
, LastStatusCde Char(1) Not Null
, LastStatusDte Date Not Null
, Constraint pkReferenceType Primary Key (TypeCde)
)
;

/*

Insert test data

*/

Insert Into ReferenceData (TypeCde, ReferenceType, TypeDescription, LastStatusCde, LastStatusDte)
Values
('Acc001', 'Account', 'Deposit Account', 'I', '2018-01-01')
, ('Acc002', 'Account', 'Investment 12 Months', 'I', '2018-01-01')
, ('Acc003', 'Account', 'Mortgage', 'I', '2018-01-01')
, ('Acc004', 'Account', 'Payment Protection Insurance', 'D', '2018-01-02')
, ('Sec001', 'Security', 'Debt Security', 'I', '2018-01-01')
, ('Sec002', 'Security', 'Equity Security', 'I', '2018-01-01')
, ('Sec003', 'Security', 'Mortgage Security', 'I', '2018-01-01')
, ('Ass001', 'Association', 'Insurance Provider', 'I', '2018-01-01')
, ('Ass002', 'Association', 'Surveyor', 'I', '2018-01-01')
, ('Ass003', 'Association', 'Accountant', 'I', '2018-01-01')
;

Select * From ReferenceData
;

/*

Test of primary key constraint. Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into ReferenceData (TypeCde, ReferenceType, TypeDescription, LastStatusCde, LastStatusDte)
Values
('Acc001', 'Account', 'Personal Loan', 'I', '2018-01-01')
;

