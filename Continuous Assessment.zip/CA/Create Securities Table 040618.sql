/*

Create Securities Table 

*/

Create Table Securities
(
  SecurityId Int Not Null
, AccountId Int Not Null
, CustomerId Int Not Null
, TypeCde Char(6) Not Null
, SecurityValue Decimal(18,2) Not Null
, ValuationDate	Date
, Constraint pkSecurities Primary Key (SecurityId)
, Constraint fkSecurityAccounts Foreign Key (AccountId) References Accounts(AccountId)
, Constraint fkSecurityCustomers Foreign Key (CustomerId) References Customers(CustomerId)
, Constraint fkSecurityTypes Foreign Key (TypeCde) References ReferenceData(TypeCde)
)
;

/*

Insert test data

*/

Insert Into Securities (SecurityId, AccountId, CustomerId, TypeCde, SecurityValue, ValuationDate)
Values
  (1, 3, 1, 'Sec003', 100000, '2018-01-01')
, (2, 5, 2, 'Sec003', 500000, '2018-01-01')
, (3, 12, 7, 'Sec003', 5000000, '2018-01-01')
, (4, 12, 7, 'Sec002', 5000000, '2018-01-01')
;

Select * From Securities
;

/*

Test of primary key constraint. Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Securities (SecurityId, AccountId, CustomerId, TypeCde, SecurityValue, ValuationDate)
Values
  (1, 5, 5, 'Sec003', 100000, '2018-01-01')
  ;

