/*

Create Associations Table

*/

Create Table Associations
(
  AssociationId Int Not Null
, CustomerIdA Int Not Null
, CustomerIdB Int Not Null
, TypeCde Char(6) Not Null
, Constraint pkAssociation Primary Key (AssociationId)
, Constraint fkAssociationCustomerA Foreign Key (CustomerIdA) References Customers(CustomerId)
, Constraint fkAssociationCustomerB Foreign Key (CustomerIdB) References Customers(CustomerId)
, Constraint fkAssociationType Foreign Key (TypeCde) References ReferenceData(TypeCde)
, Constraint ucUniqueAssociation Unique (CustomerIdA, CustomerIdB, TypeCde)
)
;

/*

Insert test data

*/

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (1, 1, 4, 'Ass001')
, (2, 2, 4, 'Ass001')
, (3, 7, 4, 'Ass001')
, (4, 7, 5, 'Ass002')
, (5, 1, 6, 'Ass003')
, (6, 2, 6, 'Ass003')
, (7, 7, 6, 'Ass003')
;

Select * From Associations
;


/*

Test of primary key constraint. Expected result is an error "Violation of Primary Key constraint"

*/

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (1, 1, 4, 'Ass003')
  ;

/*

Test Unique Constraint

Customer cannot be associated with same customer more than once with the same association type

*/

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (8, 1, 4, 'Ass001')
  ;

