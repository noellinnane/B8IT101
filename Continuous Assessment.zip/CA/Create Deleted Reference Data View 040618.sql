/*

Create Deleted Reference Data View

*/


Create View usvDeletedReferenceData
As
	Select TypeCde
	, ReferenceType
	, TypeDescription
	, LastStatusCde
	, LastStatusDte

	From ReferenceData
	
	Where LastStatusCde = 'D'

;