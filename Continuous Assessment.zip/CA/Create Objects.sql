/*

Create Table
Generic Reference Data
Allowing Soft Deletes

*/

CREATE TABLE ReferenceData
(
TypeCde	Char(6) Not Null
, ReferenceType VarChar(30) Not Null
, TypeDescription VarChar(30) Not Null
, LastStatusCde Char(1) Not Null
, LastStatusDte Date Not Null
, Constraint pkReferenceType Primary Key (TypeCde)
)
;

--Insert test data

Insert Into ReferenceData (TypeCde, ReferenceType, TypeDescription, LastStatusCde, LastStatusDte)
Values
('Acc001', 'Account', 'Deposit Account', 'I', '2018-01-01')
, ('Acc002', 'Account', 'Investment 12 Months', 'I', '2018-01-01')
, ('Acc003', 'Account', 'Mortgage', 'I', '2018-01-01')
, ('Acc004', 'Account', 'Payment Protection Insurance', 'D', '2018-01-02')
, ('Sec001', 'Security', 'Debt Security', 'I', '2018-01-01')
, ('Sec002', 'Security', 'Equity Security', 'I', '2018-01-01')
, ('Sec003', 'Security', 'Mortgage Security', 'I', '2018-01-01')
, ('Ass001', 'Association', 'Insurance Provider', 'I', '2018-01-01')
, ('Ass002', 'Association', 'Surveyor', 'I', '2018-01-01')
, ('Ass003', 'Association', 'Accountant', 'I', '2018-01-01')
;

Select * From ReferenceData
;



/*

Create table
Customers
Identity is not set as data will be imported from existing systems

*/

Create Table Customers
(
CustomerID Int Not Null
, CustomerType Char(1) Not Null
, Name VarChar(50) Not Null
, DateOfBirth Date
, Address1 VarChar(30)
, Address2 VarChar(30)
, City VarChar(30)
, County VarChar(30)
, Country VarChar(30)
, PhoneNo VarChar(20)
, Constraint pkCustomer Primary Key (CustomerID)
)
;

--Insert test data

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values
(1, 'P', 'Mr Noel Linnane', '1983-12-24', '40 Stratton Grove', 'Adamstown Square', 'Adamstown', 'Co. Dublin', 'Ireland', '0852853273')
, (2, 'P', 'Mr Peter Linnane', '1959-03-26', '36 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0876884994')
, (3, 'P', 'Mrs Catherine Linnane', '1958-04-12', '36 Courtown Park', 'Courtown Road', 'Kilcock', 'Co. Kildare', 'Ireland', '0851122698')
, (4, 'C', 'Insurance Co. Ltd', Null, '3 Sandyford Business Centre', 'Blackthorn Road', 'Sandyford', 'Co. Dublin', 'Ireland', '0162421717')
, (5, 'C', 'Surveyor Co. Ltd', Null, '4 Dunboyne Business Park', 'Dunboyne Road', 'Dunboyne', 'Co. Meath', 'Ireland', '0452543276')
, (6, 'C', 'Powderly Accountants', Null, '35 Kilcock Office Cente', 'The Square', 'Kilcock', 'Co. Kildare', 'Ireland', '016287463')
, (7, 'C', 'Castlethorn Property Development', Null, 'Usher House', 'Main Street', 'Dundrum', 'Co. Dublin', 'Ireland', '012164060')
;


Select * From Customers
;




/*

Create Table

Associations

Customers cannot be associated with the same customer more than once under the same association type

*/

Create Table Associations
(
  AssociationId Int Not Null
, CustomerIdA Int Not Null
, CustomerIdB Int Not Null
, TypeCde Char(6) Not Null
, Constraint pkAssociation Primary Key (AssociationId)
, Constraint fkAssociationCustomerA Foreign Key (CustomerIdA) References Customers(CustomerId)
, Constraint fkAssociationCustomerB Foreign Key (CustomerIdB) References Customers(CustomerId)
, Constraint fkAssociationType Foreign Key (TypeCde) References ReferenceData(TypeCde)
, Constraint ucUniqueAssociation Unique (CustomerIdA, CustomerIdB, TypeCde)
)
;

--Insert test data

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values
  (1, 1, 4, 'Ass001')
, (2, 2, 4, 'Ass001')
, (3, 7, 4, 'Ass001')
, (4, 7, 5, 'Ass002')
, (5, 1, 6, 'Ass003')
, (6, 2, 6, 'Ass003')
, (7, 7, 6, 'Ass003')
;

Select * From Associations
;



/*

Create Accounts Table

*/

Create Table Accounts
(
  AccountId Int Not Null
, CustomerId Int Not Null
, TypeCde Char(6) Not Null
, OpenDate Date Not Null 
, BalanceAmt Decimal(18,2) Not Null 
, Constraint pkAccounts Primary Key (AccountID)
, Constraint fkAccountsCustomers Foreign Key (CustomerId) References Customers(CustomerId)
, Constraint fkAccountType Foreign Key (TypeCde) References ReferenceData(TypeCde)
)
;

--Insert test data

Insert Into Accounts (AccountId, CustomerId, TypeCde, OpenDate, BalanceAmt)
Values
  (1, 1, 'Acc001', '2018-01-01', 10000)
, (2, 1, 'Acc002', '2018-01-01', 50000)
, (3, 1, 'Acc003', '2018-01-01', 100000)
, (4, 2, 'Acc001', '2018-01-01', 35000)
, (5, 2, 'Acc003', '2018-01-01', 500000)
, (6, 3, 'Acc001', '2018-01-01', 500000)
, (7, 3,'Acc001', '2018-01-01', 250000)
, (8, 4, 'Acc001', '2018-01-01', 15000000)
, (9, 5, 'Acc001', '2018-01-01', 25000000)
, (10, 6, 'Acc001', '2018-01-01', 1000000)
, (11, 7, 'Acc001', '2018-01-01', 50000000)
, (12, 7, 'Acc003', '2018-01-01', 10000000)
, (13, 7, 'Acc002', '2018-01-01', 5000000)
;

Select * from Accounts
;




/*

Create Securities Table 

*/

Create Table Securities
(
  SecurityId Int Not Null
, AccountId Int Not Null
, CustomerId Int Not Null
, TypeCde Char(6) Not Null
, SecurityValue Decimal(18,2) Not Null
, ValuationDate	Date
, Constraint pkSecurities Primary Key (SecurityId)
, Constraint fkSecurityAccounts Foreign Key (AccountId) References Accounts(AccountId)
, Constraint fkSecurityCustomers Foreign Key (CustomerId) References Customers(CustomerId)
, Constraint fkSecurityTypes Foreign Key (TypeCde) References ReferenceData(TypeCde)
)
;

--Insert test data

Insert Into Securities (SecurityId, AccountId, CustomerId, TypeCde, SecurityValue, ValuationDate)
Values
  (1, 3, 1, 'Sec003', 100000, '2018-01-01')
, (2, 5, 2, 'Sec003', 500000, '2018-01-01')
, (3, 12, 7, 'Sec003', 5000000, '2018-01-01')
, (4, 12, 7, 'Sec002', 5000000, '2018-01-01')
;

Select * From Securities
;




/*

Create View

Deleted Reference Data

*/


Create View usvDeletedReferenceData
As
	Select TypeCde
	, ReferenceType
	, TypeDescription
	, LastStatusCde
	, LastStatusDte

	From ReferenceData
	
	Where LastStatusCde = 'D'

;


/*

Create View

Associations MI

Show both sides of each association

*/

Create View usvAssocationsMi
As
	Select a.AssociationId
	, a.CustomerIdA as CustomerId
	, b.Name as CustomerName
	, a.CustomerIdB as AssociatedCustomerId
	, c.Name as AssociatedCustomerName
	, a.TypeCde
	, d.TypeDescription
	, 'Left side' as RelationshipSide

	from Associations a
	join Customers b
	on a.CustomerIdA = b.CustomerId

	join Customers c
	on a.CustomerIdB = c.CustomerId

	join ReferenceData d
	on a.TypeCde = d.TypeCde

	UNION

	Select a.AssociationId
	, a.CustomerIdB as CustomerId
	, b.Name as CustomerName
	, a.CustomerIdA as AssociatedCustomerId
	, c.Name as AssociatedCustomerName
	, a.TypeCde
	, d.TypeDescription
	, 'Right side' as RelationshipSide

	from Associations a
	join Customers b
	on a.CustomerIdB = b.CustomerId

	join Customers c
	on a.CustomerIdA = c.CustomerId

	join ReferenceData d
	on a.TypeCde = d.TypeCde
;


/*

Create Stored Procedure

New Accounts and Associations 

*/

Create Procedure uspNewAccountAndAssociation
@CustomerID Int
,@CustomerType Char(1)
,@Name VarChar(50)
,@DateOfBirth Date = Null
,@Address1 VarChar(30) = Null
,@Address2 VarChar(30) = Null
,@City VarChar(30) = Null
,@County VarChar(30) = Null
,@Country VarcHar(30) = Null
,@PhoneNo VarChar(20) = Null
,@AssociationId Int = Null
,@AssociatedCustomerId Int = Null
,@AssociationType Char(6) = Null

As

Insert Into Customers (CustomerID, CustomerType, Name, DateOfBirth, Address1, Address2, City, County, Country, PhoneNo)
Values (@CustomerID, @CustomerType, @Name, @DateOfBirth, @Address1, @Address2, @City, @County, @Country, @PhoneNo)
;

Insert Into Associations (AssociationId, CustomerIdA, CustomerIdB, TypeCde)
Values (@AssociationId, @CustomerId, @AssociatedCustomerId, @AssociationType)
;


/*

Create Stored Procedure

Delete Customer Records

*/

Create Procedure uspDeleteCustomerRecords
@CustomerId Int

AS

Delete from Securities 

Where CustomerId = @CustomerId
;

Delete From Accounts

Where CustomerId = @CustomerId
;

Delete From Associations

Where CustomerIdA = @CustomerId
;

Delete from Associations

Where CustomerIdB = @CustomerId
;

Delete From Customers

Where CustomerID = @CustomerId
;

